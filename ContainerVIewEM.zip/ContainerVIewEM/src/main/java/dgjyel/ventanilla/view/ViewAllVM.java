package dgjyel.ventanilla.view;

import java.io.Serializable;


import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.Executions;
import org.zkoss.zk.ui.event.Event;
import org.zkoss.zk.ui.event.EventListener;
import org.zkoss.zk.ui.event.Events;
import org.zkoss.zk.ui.util.GenericForwardComposer;
import org.zkoss.zul.Div;
import org.zkoss.zul.ListModelList;
import org.zkoss.zul.Listbox;
import org.zkoss.zul.Listitem;
import org.zkoss.zul.ListitemRenderer;

public class ViewAllVM extends GenericForwardComposer implements Serializable{
	
	
	
	ListModelList menuModel = new ListModelList();
	Listbox menuListbox;
	MenuNodeSelectListener listener = new MenuNodeSelectListener();
	MenuNodeItemRenderer renderer = new MenuNodeItemRenderer();
	Div contentDiv;
	
	public ViewAllVM(){
		
		//menuModel.add(new MenuNode("ALTAS","/borderLayout/automovilAltas.zul"));
		menuModel.add(new MenuNode("COPIAS","/container/tramites/copias/copias.zul"));
		menuModel.add(new MenuNode("COPIAS SIMPLES","/container/tramites/copias/copias-simples.zul"));	
		//menuModel.add(new MenuNode("RECUPERACION","/borderLayout/automovilRecuperacionList.zul"));
		//menuModel.add(new MenuNode("REPORTES","/borderLayout/automovilReportes.zul"));
		//menuModel.add(new MenuNode("ESTADISTICAS","/borderLayout/automovilEstadisticas.zul"));
		
	}
	
	
	
	public void doAfterCompose(Component comp) throws Exception {
		super.doAfterCompose(comp);
		
		menuListbox.setModel(menuModel);
		menuListbox.setItemRenderer(renderer);
		menuListbox.addEventListener(Events.ON_SELECT,listener);
	}
	
	class MenuNode {
		String label;
		String link;

		public MenuNode(String label,String link){
			this.label = label;
			this.link = link;
		}
		public String getLabel() {
			return label;
		}
		public void setLabel(String label) {
			this.label = label;
		}
		public String getLink() {
			return link;
		}
		public void setLink(String link) {
			this.link = link;
		}
	}
	
	class MenuNodeItemRenderer implements ListitemRenderer{		
		public void render(Listitem item, Object data, int index) throws Exception {
			MenuNode node = (MenuNode)data;
			if(node.getLabel()=="COPIAS"){					
					item.setImage("/images/application/search_60x50.png");
					item.setLabel(node.getLabel());
					item.setValue(node);
			}
			if(node.getLabel()=="COPIAS SIMPLES"){					
				item.setImage("/images/application/search_60x50.png");
				item.setLabel(node.getLabel());
				item.setValue(node);
		}
			
		}
	}
	

	class MenuNodeSelectListener implements EventListener{
		public void onEvent(Event event) throws Exception {
			Listitem item = menuListbox.getSelectedItem();
			contentDiv.getChildren().clear();
			if(item!=null){
				MenuNode node = (MenuNode)item.getValue();
				Executions.createComponents(node.getLink(),contentDiv,null);
			}
		}		
	}

}
